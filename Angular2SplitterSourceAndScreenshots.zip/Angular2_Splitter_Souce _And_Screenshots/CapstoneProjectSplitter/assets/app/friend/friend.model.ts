export class Friend {
    constructor(public fName: string,
                public lName: string,
                public email: string,
                public userName: string,
                public userId: string,
                public message?: string
    ) {
    }
}