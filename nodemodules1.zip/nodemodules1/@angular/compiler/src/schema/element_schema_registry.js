/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
export var ElementSchemaRegistry = (function () {
    function ElementSchemaRegistry() {
    }
    return ElementSchemaRegistry;
}());
//# sourceMappingURL=element_schema_registry.js.map