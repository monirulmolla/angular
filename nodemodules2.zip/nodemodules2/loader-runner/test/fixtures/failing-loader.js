module.exports = function(source) {
	throw new Error(source);
};
