module.exports = function(source) {
	return source;
};
module.exports.pitch = function(rem, prev, data) {
	data.identity = true;
};
